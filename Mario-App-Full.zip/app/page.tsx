"use client";

import { useEffect, useState } from "react";
import { ethers } from "ethers";

export default function Home() {
  const [account, setAccount] = useState<string | null>(null);
  const [audio, setAudio] = useState<HTMLAudioElement | null>(null);

  const connectWallet = async () => {
    if (typeof window.ethereum !== "undefined") {
      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts",
      });
      setAccount(accounts[0]);
    } else {
      alert("Install MetaMask dulu ya!");
    }
  };

  const handlePlayMusic = () => {
    if (!audio) {
      const newAudio = new Audio("/mario-theme.mp3");
      newAudio.loop = true;
      newAudio.play();
      setAudio(newAudio);
    } else {
      audio.paused ? audio.play() : audio.pause();
    }
  };

  const handleClaimReward = () => {
    if (!account) {
      alert("Hubungkan wallet dulu ya!");
    } else {
      alert("🎁 Reward Mon Token NFT berhasil diklaim (simulasi)");
    }
  };

  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-yellow-100 to-pink-100 text-center p-4">
      <h1 className="text-4xl font-bold mb-4">🎮 Mario Wallet Reward</h1>

      <img src="/mario.png" alt="Mario" className="w-40 mb-6 drop-shadow-lg" />

      <button
        onClick={handlePlayMusic}
        className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-full mb-4"
      >
        🎵 Mainkan Musik
      </button>

      <button
        onClick={connectWallet}
        className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-full mb-4"
      >
        🔌 {account ? `Terhubung: ${account.slice(0, 6)}...` : "Connect Wallet"}
      </button>

      <button
        onClick={handleClaimReward}
        className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-full"
      >
        🎁 Klaim Hadiah Mon Token NFT
      </button>
    </main>
  );
}
